package test;

import org.testng.annotations.Test;

import pageObject.HomePage;
import utility.BaseClass;

public class HomeTest extends BaseClass {
  @Test
  public void Home() {
	 
	  HomePage h=new HomePage(driver);
	  h.Home();
	  
  }
}
