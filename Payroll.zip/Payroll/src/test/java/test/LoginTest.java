package test;

import org.testng.annotations.Test;

import pageObject.LoginPage;
import utility.BaseClass;

public class LoginTest extends BaseClass {
	
  @Test(dataProvider="dp")
  public void main(String n,String p) {
	  
	  LoginPage l=new LoginPage(driver);
	  l.Login(n, p);
	  
  }
}
