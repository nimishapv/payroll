package test;

import org.testng.annotations.Test;

import pageObject.ApprovedTimeSheet;
import utility.BaseClass;

public class ApprovedTimeSheetTest extends BaseClass {
  @Test void f() {
	  
	  ApprovedTimeSheet a =new ApprovedTimeSheet(driver);
	  a.approvedTSheet();
  }
}
