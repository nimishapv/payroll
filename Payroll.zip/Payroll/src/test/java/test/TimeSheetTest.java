package test;

import org.testng.annotations.Test;

import pageObject.TimeSheet;
import utility.BaseClass;

public class TimeSheetTest extends BaseClass {
	
  @Test
  public void f () {
	  
	  TimeSheet t;
	  t=new TimeSheet(driver);
	  t.buttonAlerts();
  }
}
