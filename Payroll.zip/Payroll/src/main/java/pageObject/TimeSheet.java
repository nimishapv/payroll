package pageObject;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TimeSheet {
	WebDriver driver;
	@FindBy(className="btn btn-warning btn-responsive playslip")
	WebElement payslip;
	@FindBy(className="btn btn-warning btn-responsive invoice")
	WebElement invoice;

	public void buttonAlerts()
	{
		payslip.click();
		Alert al=driver.switchTo().alert();
		System.out.println(al.getText());
		al.accept();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		al.accept();
		invoice.click();
		System.out.println(al.getText());
		al.accept();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		al.accept();
		
	}
	
	public TimeSheet(WebDriver driver)
	
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
}
